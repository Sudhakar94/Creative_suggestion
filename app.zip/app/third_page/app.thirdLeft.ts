import { Component } from '@angular/core';
import { ContactService } from './app.contactService';

import {Contact} from './contact';

@Component({
  selector: 'third-left',
  templateUrl:'./app/third_page/third_left.html',
   styleUrls:['./app/third_page/css/third_left.css'],
 
        providers:[ContactService]    

            
})

export class thirdLeftComponent{
	contacts: Array<Contact>;
  constructor(contactService:ContactService){
  	
  	this.contacts = [];
  	var abc=this.contacts;
  	contactService.getDatas(abc);
  }
  
   addContact(name,phone){
        let contact = new Contact(name,phone);
        this.contacts.push(contact);
        console.log(contact);
    }
        removeContact(contact){
        let index = this.contacts.indexOf(contact);
        this.contacts.splice(index,1);
    }


}