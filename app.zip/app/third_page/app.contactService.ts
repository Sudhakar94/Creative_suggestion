export class ContactService{




	getDatas(contacts){
	
	let mathew=contacts;
	return mathew;

	
	}

	/*
		setInfo : function(value){
			facData = value;
		},
		getInfo : function(){
			return facData;
		},
	*/
}