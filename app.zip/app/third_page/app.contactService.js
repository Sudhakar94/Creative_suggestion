"use strict";
var ContactService = (function () {
    function ContactService() {
    }
    ContactService.prototype.getDatas = function (contacts) {
        var mathew = contacts;
        return mathew;
    };
    return ContactService;
}());
exports.ContactService = ContactService;
//# sourceMappingURL=app.contactService.js.map