"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var secondComponent = (function () {
    function secondComponent(router) {
        this.count = 0;
    }
    secondComponent.prototype.postFunction = function (content) {
        this.textContent = content;
        this.content = "";
    };
    secondComponent.prototype.likeCount = function () {
        this.count = this.count + 1;
    };
    secondComponent.prototype.comntPost = function (jstContnt) {
        this.comntContent = jstContnt;
        this.jstContnt = "";
    };
    secondComponent.prototype.commEnt = function () {
        this.sudhaText = "true";
    };
    secondComponent = __decorate([
        core_1.Component({
            selector: 'secon',
            templateUrl: './app/second_page/second.html',
            styleUrls: ['./app/second_page/css/second.css'],
        }), 
        __metadata('design:paramtypes', [router_1.Router])
    ], secondComponent);
    return secondComponent;
}());
exports.secondComponent = secondComponent;
//# sourceMappingURL=app.second.js.map