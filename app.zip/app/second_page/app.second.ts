import { Component } from '@angular/core';
import { ngModel } from '@angular/forms';
import {Router} from '@angular/router';



@Component({
  selector: 'secon',
  templateUrl:'./app/second_page/second.html',
   styleUrls:['./app/second_page/css/second.css'],
 
            

            
})

export class secondComponent{ 
  count=0;
  constructor(router:Router){

  	
  }

  postFunction(content){

    this.textContent=content;
    this.content="";
  	
  }
  likeCount(){
    
    this.count=this.count+1;
    
  }
  comntPost(jstContnt){
    this.comntContent=jstContnt;
    this.jstContnt="";
  }
  commEnt(){
    this.sudhaText="true";
  }
  

 }