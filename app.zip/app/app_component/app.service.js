"use strict";
var LoginService = (function () {
    function LoginService() {
    }
    LoginService.prototype.getData = function () {
        var dad = [
            { "name": "sudhakar", "age": "sudhakar" },
            { "name": "srini", "age": "23" },
            { "name": "aaa", "age": "aaa" },
            { "name": "nandhini", "age": "abc" },
            { "name": "mohanapriya", "age": "21" },
            { "name": "shankar", "age": "24" }
        ];
        return dad;
    };
    LoginService.prototype.inputData = function () {
        return;
    };
    return LoginService;
}());
exports.LoginService = LoginService;
//# sourceMappingURL=app.service.js.map