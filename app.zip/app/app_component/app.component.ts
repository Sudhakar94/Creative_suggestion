import { Component } from '@angular/core';
import { ngModel } from '@angular/forms';
import {Location} from '@angular/common';
import {Router} from '@angular/router';

import { LoginService } from './app.service';

@Component({
  selector: 'login',
  templateUrl:'./app/app_component/login.html',
   styleUrls:['./app/app_component/css/login.css'],

  providers:[LoginService]
            

            
})

export class loginComponent{ 
  
  constructor(loginService:LoginService,router:Router){

    this.abc=loginService.getData();
    this.router=router;
  }

  public eventHandler(event,userName,password) {
   
     if(event.keyCode=="13"){
           this.clickedSubmit(userName,password)    
       }
  }

  clickedSubmit(userName,password){
    let data=this.abc;

    let justDummy="cx";
    let ponewName="ENTER CORRECT CREDENTIALS";

    data.forEach(function(aname)
                  {
                  
                    console.log(aname);
                    
                    if(aname.name==userName )
                      {
                       
                         if(aname.age==password)
                            {
                              
                                 
                                 justDummy="truue"
                            }
                          else if(aname.age!=password){
                              
                              ponewName="password wrong";
                          }
                       }
                            
                   }
                   if(justDummy=="truue")
                   {
                    this.router.navigate(['/third']);
                   }
                  

                   this.newName=ponewName;
}
} 