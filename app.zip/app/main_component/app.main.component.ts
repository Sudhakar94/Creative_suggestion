import { Component } from '@angular/core';



@Component({
  selector: 'main',
  templateUrl:'./app/main_component/main.html',
   styleUrls:['./app/main_component/css/main.css']

            

            
})

export class mainComponent{ 
  
  
 
 }